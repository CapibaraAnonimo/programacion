package ejercicio1;

public class Producto {
	private String nombre;
	private int codProd;
	private int taxacion;
	private double a;

}
