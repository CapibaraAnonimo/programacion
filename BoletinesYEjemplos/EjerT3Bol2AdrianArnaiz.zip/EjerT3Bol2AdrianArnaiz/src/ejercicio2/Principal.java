package ejercicio2;

public class Principal {

	public static void main(String[] args) {
		int tam;
		Habitacion lista[];
		Hotel h;

		
	}

}
