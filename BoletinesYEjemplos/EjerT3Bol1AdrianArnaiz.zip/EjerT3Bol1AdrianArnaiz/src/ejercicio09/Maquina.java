package ejercicio09;

public class Maquina {

}
