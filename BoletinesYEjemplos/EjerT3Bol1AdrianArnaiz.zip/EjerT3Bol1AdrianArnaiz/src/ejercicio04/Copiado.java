package ejercicio04;

public class Copiado 
{
	public Copiado() 
	{
	}
	
	public void copiar(String cadena, int veces)
	{
		for(int i = 0; i < veces; i++)
		{
			System.out.println(cadena);
		}
	}

}
