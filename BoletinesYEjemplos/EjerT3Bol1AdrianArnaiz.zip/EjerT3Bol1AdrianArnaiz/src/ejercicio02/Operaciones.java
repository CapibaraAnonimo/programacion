package ejercicio02;

public class Operaciones 
{
	
	public void Operadores()
	{	
	}
	
	public boolean positivo(int num)
	{	
		if(num >= 0)
		{
			return true;
		}else {
			return false;
		}
	}
	
	public boolean par(int num)
	{
		if(num%2 == 0)
		{
			return true;
		}else {
			return false;
		}
	}

}
